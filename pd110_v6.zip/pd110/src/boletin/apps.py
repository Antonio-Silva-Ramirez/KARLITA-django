from django.apps import AppConfig


class BoletinConfig(AppConfig):
    name = 'boletin'
