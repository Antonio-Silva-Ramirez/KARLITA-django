from django.shortcuts import render

# Create yours views here.

def about(request):
	return render (request, "about.html", {})