from django.apps import AppConfig


class BoletinConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'boletin'
